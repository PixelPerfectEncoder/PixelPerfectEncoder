from PixelPerfect.Tests.a3_tests import *

if __name__ == "__main__":
    run_e1()
